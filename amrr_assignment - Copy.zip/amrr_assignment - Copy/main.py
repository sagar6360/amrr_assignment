from fastapi import FastAPI, HTTPException

app = FastAPI()

# Sample user data (in-memory storage)
users = [
    {"user_id": 1, "name": "sagar", "email": "sagar@example.com", "phone": "8787870909", "wallet_balance": 100.0},
    {"user_id": 2, "name": "babu", "email": "babu@example.com", "phone": "0987654321", "wallet_balance": 50.0}
]

# Sample transaction storage
transactions = []

# Root endpoint (optional, for testing)
@app.get("/")
def read_root():
    return {"message": "Hello, AMRR TechSols Assignment!"}

# List Users API
@app.get("/users")
def list_users():
    return users

# Update Wallet API
@app.put("/update_wallet/{user_id}")
def update_wallet(user_id: int, amount: float):
    for user in users:
        if user["user_id"] == user_id:
            if amount <= 0:
                raise HTTPException(status_code=400, detail="Amount must be positive")
            user["wallet_balance"] += amount
            transactions.append({
                "user_id": user_id,
                "amount": amount,
                "timestamp": "2025-09-02"  # Hardcoded for simplicity
            })
            return {"message": f"Wallet updated for user {user_id}. New balance: {user['wallet_balance']}"}
    raise HTTPException(status_code=404, detail="User not found")

# Fetch Transactions API
@app.get("/transactions/{user_id}")
def fetch_transactions(user_id: int):
    user_transactions = [t for t in transactions if t["user_id"] == user_id]
    if not user_transactions:
        raise HTTPException(status_code=404, detail="No transactions found")
    return user_transactions